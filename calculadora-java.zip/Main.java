/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Digite o primeiro numero:");
	    double num1 = scanner.nextDouble();
	    System.out.println("Digite seu segundo numero:");
	    double num2 = scanner.nextDouble();
	    scanner.nextLine();
	    System.out.println("Digite a operação:");
	    String operação = scanner.nextLine().toLowerCase();
	    
	    switch(operação){
	    case "soma": 
	    System.out.println("O resultado foi:"+ (num1+num2));
	    break;
	    case "subtração":
	    System.out.println("O resultado foi:" +(num1 - num2));
	    break;
	    case "divisão":
	    System.out.println("O resultado foi:" +(num1/num2));
	    break;
	    case "multiplicaçao":
	    System.out.println("O resultado foi:" +(num1*num2));
	        break;
	    }
	  
	    scanner.close();
	    
	}
}
